import { apiClient } from './apiService';

const authService = {
  login: async (username, password) => {
    try {
      // 1. Llamada al backend Python para login
      const loginResponse = await apiClient.post('/usuarios/login', { 
        correo: username, 
        clave: password 
      });

      const { UsuarioID } = loginResponse.data;

      // Por ahora, crear un token mock y datos de usuario completos
      const mockToken = 'mock-jwt-token-' + UsuarioID;
      
      const userComplete = {
        id: UsuarioID,
        username: username,
        name: username.split('@')[0],
        email: username,
        rol: {
          id: 1,
          nombre: 'Admin'
        },
        permisos: {
          torre_de_control: true,
          financiero: true,
          recursos_humanos: true,
          metas: true
        },
        // Campañas por defecto para Torre de Control
        campanas: [
          { id: 1, nombre: 'NPL COL', fechaCreacion: new Date().toISOString() },
          { id: 2, nombre: 'ACC', fechaCreacion: new Date().toISOString() },
          { id: 3, nombre: 'NPL CHILE', fechaCreacion: new Date().toISOString() },
          { id: 4, nombre: 'NPL PERU', fechaCreacion: new Date().toISOString() }
        ],
        permissions: ['view_kpi', 'edit_kpi', 'view_finance', 'edit_finance', 'view_hr', 'edit_hr', 'metas'],
        roles: ['admin']
      };

      return {
        token: mockToken,
        user: userComplete,
      };
    } catch (error) {
      console.error('Error en login:', error);
      throw new Error(error.response?.data?.detail || 'Credenciales inválidas');
    }
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  getCurrentUser: () => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  hasPermission: (permission) => {
    const user = authService.getCurrentUser();
    return user?.permissions?.includes(permission) || false;
  },

  hasRole: (role) => {
    const user = authService.getCurrentUser();
    return user?.roles?.includes(role) || false;
  },
};

export default authService;
