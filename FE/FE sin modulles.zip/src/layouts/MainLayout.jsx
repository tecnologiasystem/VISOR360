import React from 'react';
import { Layout, Menu, Avatar, Dropdown, theme } from 'antd';
import {
  DashboardOutlined,
  DollarOutlined,
  TeamOutlined,
  LogoutOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './MainLayout.css';

const { Header, Content } = Layout;

const MainLayout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  // Construir menú basado en permisos del usuario
  const allMenuItems = [
    {
      key: '/kpi',
      icon: <DashboardOutlined />,
      label: 'Torre de Control',
      permission: 'torre_de_control',
    },
    {
      key: '/financiero',
      icon: <DollarOutlined />,
      label: 'Análisis Financiero',
      permission: 'financiero',
    },
    {
      key: '/talento',
      icon: <TeamOutlined />,
      label: 'Talento Humano',
      permission: 'recursos_humanos',
    },
    {
      key: '/gestion-metas',
      icon: <DollarOutlined />,
      label: 'Gestión de Metas',
      permission: null,
    },
  ];

  // Filtrar menú según permisos del usuario
  const menuItems = allMenuItems.filter(item => {
    // Si no tiene permiso definido (como gestión de metas), dejarlo pasar
    if (!item.permission) return true;
    return user?.permisos?.[item.permission] === true;
  });

  const handleMenuClick = ({ key }) => {
    navigate(key);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const userMenuItems = [
    {
      key: 'info',
      label: (
        <div style={{ padding: '8px 0', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>{user?.name}</div>
          <div style={{ fontSize: '12px', color: '#8c8c8c' }}>
            {user?.rol?.nombre || 'Sin rol'}
          </div>
          {user?.campanas && user.campanas.length > 0 && (
            <div style={{ fontSize: '11px', color: '#1890ff', marginTop: 4 }}>
              {user.campanas.length} campaña(s) asignada(s)
            </div>
          )}
        </div>
      ),
      disabled: true,
    },
    {
      type: 'divider',
    },
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Perfil',
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Cerrar Sesión',
      onClick: handleLogout,
    },
  ];

  return (
    <Layout style={{ minHeight: '100vh' }}>
      {/* Header superior fijo */}
      <Header
        className="qa-header"
        style={{
          position: 'fixed',
          top: 0,
          zIndex: 1000,
          width: '100%',
          background: '#001529',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 24px',
          height: 64,
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
        }}
      >
        {/* Logo + Navegación */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '32px' }}>
          <div
            style={{
              color: '#fff',
              fontWeight: 600,
              fontSize: 18,
              cursor: 'pointer',
            }}
            onClick={() => navigate('/kpi')}
          >
            Sistema QA
          </div>
          <Menu
            theme="dark"
            mode="horizontal"
            selectedKeys={[location.pathname]}
            items={menuItems}
            onClick={handleMenuClick}
            style={{
              background: 'transparent',
              borderBottom: 'none',
              minWidth: 400,
            }}
          />
        </div>

        {/* Perfil de usuario */}
        <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
          <div className="user-menu" style={{ cursor: 'pointer' }}>
            <Avatar
              style={{ backgroundColor: '#003087', marginRight: 8 }}
              icon={<UserOutlined />}
            />
            <span
              className="user-name"
              style={{ color: '#fff', fontWeight: 500 }}
            >
              {user?.name || 'Administrador'}
            </span>
          </div>
        </Dropdown>
      </Header>

      {/* Contenido principal */}
      <Content
        style={{
          marginTop: 84, // para dejar espacio al header fijo
          marginLeft: 0,
          padding: 24,
          background: colorBgContainer,
          borderRadius: 8,
          minHeight: 'calc(100vh - 84px)',
          transition: 'all 0.3s',
        }}
      >
        <Outlet />
      </Content>
    </Layout>
  );
};

export default MainLayout;

