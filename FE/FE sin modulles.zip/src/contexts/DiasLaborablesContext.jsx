// Context para compartir configuración de días laborables entre componentes
import React, { createContext, useContext, useState, useMemo } from "react";
import dayjs from "dayjs";

const DiasLaborablesContext = createContext();

export const useDiasLaborables = () => {
  const context = useContext(DiasLaborablesContext);
  if (!context) {
    throw new Error("useDiasLaborables debe usarse dentro de DiasLaborablesProvider");
  }
  return context;
};

export const DiasLaborablesProvider = ({ children }) => {
  // Inicializar con los días laborables del mes actual (L-V)
  const [diasLaborablesCustom, setDiasLaborablesCustom] = useState(() => {
    const hoy = dayjs();
    const primerDia = hoy.startOf("month");
    const finMes = hoy.endOf("month");
    const dias = [];
    
    for (let d = primerDia; d.isBefore(finMes) || d.isSame(finMes, "day"); d = d.add(1, "day")) {
      const dow = d.day();
      if (dow !== 0 && dow !== 6) { // L-V
        dias.push({
          fecha: d.format("YYYY-MM-DD"),
          activo: true,
          label: d.format("DD/MM")
        });
      }
    }
    return dias;
  });

  // Calcular días restantes basado en configuración custom (INCLUYENDO HOY)
  const diasRestantes = useMemo(() => {
    const hoy = dayjs().format("YYYY-MM-DD");
    return diasLaborablesCustom.filter(d => d.activo && d.fecha >= hoy).length;
  }, [diasLaborablesCustom]);

  // Calcular total de días laborables del mes
  const totalDiasLaborables = useMemo(() => {
    return diasLaborablesCustom.filter(d => d.activo).length;
  }, [diasLaborablesCustom]);

  // Calcular días transcurridos (sin incluir hoy)
  const diasTranscurridos = useMemo(() => {
    const hoy = dayjs().format("YYYY-MM-DD");
    return diasLaborablesCustom.filter(d => d.activo && d.fecha < hoy).length;
  }, [diasLaborablesCustom]);

  const toggleDiaLaborable = (fecha) => {
    setDiasLaborablesCustom(prev => 
      prev.map(d => d.fecha === fecha ? { ...d, activo: !d.activo } : d)
    );
  };

  const resetDias = () => {
    setDiasLaborablesCustom(prev => prev.map(d => ({ ...d, activo: true })));
  };

  const value = {
    diasLaborablesCustom,
    diasRestantes,
    totalDiasLaborables,
    diasTranscurridos,
    toggleDiaLaborable,
    resetDias,
    setDiasLaborablesCustom
  };

  return (
    <DiasLaborablesContext.Provider value={value}>
      {children}
    </DiasLaborablesContext.Provider>
  );
};
