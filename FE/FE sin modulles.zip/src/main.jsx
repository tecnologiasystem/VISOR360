import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import 'antd/dist/reset.css'
import App from './App.jsx'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false, // No reintentar si falla
      refetchOnWindowFocus: false, // No refetch al enfocar ventana
      staleTime: 5 * 60 * 1000, // 5 minutos
      onError: (error) => {
        console.warn('Query error (backend no disponible):', error.message);
      }
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>,
)