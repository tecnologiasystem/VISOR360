import React, { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const formatMonth = (timestamp) => {
  const date = new Date(timestamp);
  return date.toLocaleString("es-ES", { month: "long" });
};

import { apiClient } from "../services/apiService";
import apiMain from "../api";

// Función para predecir usando promedio móvil ponderado exponencial
// Da más peso a los meses recientes (60% último mes, 30% penúltimo, 10% antepenúltimo)
const predecirSiguienteMes = (dataPoints) => {
  if (dataPoints.length < 2) return null;
  
  const n = dataPoints.length;
  
  if (n === 2) {
    // Con 2 puntos: 70% último, 30% anterior
    return dataPoints[1] * 0.7 + dataPoints[0] * 0.3;
  }
  
  // Con 3 o más puntos: usar los últimos 3 con pesos exponenciales
  const ultimos3 = dataPoints.slice(-3);
  const pesos = [0.1, 0.3, 0.6]; // más peso al más reciente
  
  const promedioPonderado = ultimos3.reduce((sum, val, i) => sum + val * pesos[i], 0);
  
  // Calcular tasa de cambio del último mes
  const tasaCambio = (ultimos3[2] - ultimos3[1]) / ultimos3[1];
  
  // Si la tendencia es muy negativa, limitar la caída
  const factorAjuste = tasaCambio < -0.2 ? 0.5 : 1.0; // limitar caídas mayores al 20%
  
  const prediccion = promedioPonderado + (promedioPonderado * tasaCambio * factorAjuste);
  
  return prediccion > 0 ? prediccion : promedioPonderado * 0.8; // mínimo 80% del promedio
};

export default function ComparativoNPL({ nombreCampana }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      if (!nombreCampana) return;
      try {
        // Definir específicamente septiembre, octubre y noviembre 2025
        const months = [
          { mes: 9, anio: 2025, label: 'septiembre' },
          { mes: 10, anio: 2025, label: 'octubre' },
          { mes: 11, anio: 2025, label: 'noviembre' }
        ];

        const results = await Promise.all(months.map(async (m) => {
          try {
            const paisName = encodeURIComponent(nombreCampana);
            // Fetch Recaudo
            const respRecaudo = await apiClient.get(`/recaudos/pais_by_name/${paisName}`, { 
              params: { mes: m.mes, anio: m.anio } 
            });
            const recaudo = respRecaudo.data?.recaudo_total || respRecaudo.data?.total_pais || 0;

            // Fetch Meta desde la nueva tabla metas_campana_pequena
            let meta = 0;
            try {
              const respMeta = await apiMain.get(`/metas-campana/pais/${paisName}`, {
                params: { mes: m.mes, anio: m.anio }
              });
              meta = respMeta.data?.meta_total || 0;
            } catch (e) {
              meta = 0;
            }

            return {
              mes: m.label,
              recaudo: recaudo,
              meta: meta,
              real: true
            };
          } catch (e) {
            return { mes: m.label, recaudo: 0, meta: 0, real: true };
          }
        }));

        // Calcular predicción para diciembre
        const recaudos = results.map(r => r.recaudo);
        const metas = results.map(r => r.meta);
        
        const recaudoPrediccion = predecirSiguienteMes(recaudos);
        const metaPrediccion = predecirSiguienteMes(metas);
        
        if (recaudoPrediccion !== null && metaPrediccion !== null) {
          results.push({
            mes: 'diciembre (pred.)',
            recaudo: recaudoPrediccion,
            meta: metaPrediccion,
            real: false
          });
        }

        setData(results);
      } catch (err) {
        console.error("Error cargando datos comparativos:", err);
      }
    };

    loadData();
  }, [nombreCampana]);

  return (
    <div className="comparativo-container" style={{ 
      maxWidth: '900px', 
      margin: '0 auto',
      padding: '20px'
    }}>
      <h2 className="chart-title">Comparativo NPL Colombia</h2>

      <ResponsiveContainer width="100%" height={350}>
        <LineChart 
          data={data} 
          margin={{ top: 20, right: 60, left: 20, bottom: 20 }}
        >
          <XAxis 
            dataKey="mes" 
            stroke="#003087"
            padding={{ left: 30, right: 30 }}
          />
          <YAxis
            stroke="#003087"
            width={80}
            tickFormatter={(v) => {
              if (v >= 1000000) return `$${(v / 1000000).toFixed(1)}M`;
              if (v >= 1000) return `$${(v / 1000).toFixed(0)}k`;
              return `$${v}`;
            }}
          />
          <Tooltip formatter={(v) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(v)} />
          <Legend
            verticalAlign="bottom"
            height={36}
            formatter={(value) =>
              value === "recaudo" ? "Recaudo" : "Meta"
            }
          />

          <Line
            type="monotone"
            dataKey="recaudo"
            stroke="#003087"
            strokeWidth={3}
            dot={(props) => {
              const { cx, cy, payload } = props;
              return (
                <circle
                  cx={cx}
                  cy={cy}
                  r={6}
                  fill={payload.real ? "#003087" : "white"}
                  stroke="#003087"
                  strokeWidth={2}
                  strokeDasharray={payload.real ? "0" : "4 2"}
                />
              );
            }}
            activeDot={{ r: 8 }}
            strokeDasharray={(entry) => entry && !entry.real ? "5 5" : "0"}
          />
          <Line 
            type="monotone" 
            dataKey="meta" 
            stroke="#F59E0B" 
            strokeWidth={3}
            dot={(props) => {
              const { cx, cy, payload } = props;
              return (
                <circle
                  cx={cx}
                  cy={cy}
                  r={6}
                  fill={payload.real ? "#F59E0B" : "white"}
                  stroke="#F59E0B"
                  strokeWidth={2}
                  strokeDasharray={payload.real ? "0" : "4 2"}
                />
              );
            }}
            activeDot={{ r: 8 }}
            strokeDasharray={(entry) => entry && !entry.real ? "5 5" : "0"}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
