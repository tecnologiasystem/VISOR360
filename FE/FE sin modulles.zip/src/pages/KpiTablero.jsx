import React, { useState, useEffect } from "react";
import "./KpiTablero.css";
import dayjs from "dayjs";
import "dayjs/locale/es";
dayjs.locale("es");
import { Select, DatePicker, Button, Space, Spin, Modal } from "antd";
import ComparativoNPL from "./ComparativoNPL";
import SeccionCampanias from "../components/SeccionCampanias";
import SeccionIndicadores from "../components/SeccionIndicadores";
import HistoricoCumplimiento from "../components/HistoricoCumplimiento";
import { Collapse } from "antd";
import { useAuth } from "../contexts/AuthContext";
import { useDiasLaborables } from "../contexts/DiasLaborablesContext";
import { apiClient } from "../services/apiService";
import api from "../api";

const { Option } = Select;

const META = {
  CLIENTES_TOTALES: { label: "Clientes asignados", agg: "last", fmt: "num" },
  CLIENTES_GESTIONABLES: { label: "Clientes con acuerdo", agg: "last", fmt: "num" },
  RECAUDO_Q: { label: "Recaudo a la fecha", agg: "sum", fmt: "num" },
  META: { label: "Meta", agg: "last", fmt: "money0" },
  CLIENTES_CONTACTADOS: { label: "Clientes contactados", agg: "sum", fmt: "num" },
  TICKET_CONTACTO: { label: "Ticket Promedio día", agg: "last", fmt: "money0" },
  ACUERDOS_Q: { label: "Total acuerdos", agg: "sum", fmt: "num" },
  ACUERDOS_DOLAR: { label: "Acuerdos $", agg: "sum", fmt: "money0" },
  TICKET_ACUERDOS: { label: "Monto Prom x Acuerdo", agg: "last", fmt: "money0" },
  EFECTIVIDAD: { label: "Efectividad", agg: "last", fmt: "percent2" },
  PLANTA: { label: "Planta", agg: "last", fmt: "num" },
};

const fmt = {
  num: (v) => (v == null ? "0" : Intl.NumberFormat('es-CO').format(v)),
  money0: (v) => v == null ? "$0" : Intl.NumberFormat('es-CO', {
    style: "currency", currency: "COP", maximumFractionDigits: 0
  }).format(v),
  percent2: (v) => v == null ? "0%" : Intl.NumberFormat('es-CO', {
    style: "percent", maximumFractionDigits: 2
  }).format(v),
};

function workdaysInMonth(d) {
  const start = d.startOf("month"), end = d.endOf("month");
  let n = 0;
  for (let cur = start; cur.isBefore(end) || cur.isSame(end, "day"); cur = cur.add(1, "day")) {
    const dow = cur.day();
    if (dow !== 0 && dow !== 6) n++;
  }
  return n;
}

function workIndexUpTo(d) {
  const start = d.startOf("month");
  let n = 0;
  for (let cur = start; cur.isBefore(d) || cur.isSame(d, "day"); cur = cur.add(1, "day")) {
    const dow = cur.day();
    if (dow !== 0 && dow !== 6) n++;
  }
  return n;
}

const KpiTablero = () => {
  const { user } = useAuth();
  const { diasRestantes: daysToGo, totalDiasLaborables } = useDiasLaborables();
  const now = dayjs();
  // Por defecto mostrar noviembre 2025 (último mes con datos)
  const [monthState, setMonthState] = useState(dayjs('2025-11-01'));
  const [activeTab, setActiveTab] = useState("actual");
  const [campanaId, setCampanaId] = useState(user?.campanas?.[0]?.id || null);
  const [selectedMonth, setSelectedMonth] = useState("Ago");
  const [recaudoData, setRecaudoData] = useState(null);
  const [loadingRecaudo, setLoadingRecaudo] = useState(false);
  const [dailySeries, setDailySeries] = useState([]);
  const [showPowerBI, setShowPowerBI] = useState(false);
  const [metaTotal, setMetaTotal] = useState(0);

  // Obtener campañas del usuario
  const campanas = user?.campanas || [];

  // Función para cargar las metas
  const cargarMeta = async () => {
    if (!campanaId) return;
    
    const campanaSeleccionada = campanas.find(c => c.id === campanaId);
    if (!campanaSeleccionada) return;
    
    const name = campanaSeleccionada.nombre || '';
    if (/npl|acc/i.test(name)) {
      try {
        const mes = monthState.month() + 1;
        const anio = monthState.year();
        const paisName = encodeURIComponent(name);
        const response = await api.get(`/metas-campana/pais/${paisName}`, {
          params: { mes, anio }
        });
        setMetaTotal(response.data.meta_total || 0);
      } catch (error) {
        console.error('Error al cargar meta:', error);
        setMetaTotal(0);
      }
    }
  };

  // Función para cargar el recaudo
  const cargarRecaudo = async () => {
    if (!campanaId) return;
    
    // Buscar el nombre de la campaña seleccionada
    const campanaSeleccionada = campanas.find(c => c.id === campanaId);
    if (!campanaSeleccionada) return;
    
    setLoadingRecaudo(true);
    try {
      const mes = monthState.month() + 1; // dayjs months are 0-indexed
      const anio = monthState.year();
      
      // Si es "Al día de hoy", agregar parámetro hasta_hoy=true
      const params = { mes, anio };
      if (activeTab === 'actual') {
        params.hasta_hoy = 'true';
      }
      
      // If the selected campaign is a "campaign-grande" (NPL, ACC, etc.) request by country name
      const name = campanaSeleccionada.nombre || '';
      if (/npl|acc/i.test(name)) {
        const paisName = encodeURIComponent(name);
        const resp = await apiClient.get(`/recaudos/pais_by_name/${paisName}`, { params: { mes, anio } });
        setRecaudoData(resp.data);
        // fetch daily series
        try {
          const resp2 = await apiClient.get(`/recaudos/pais_by_name/${paisName}/diario`, { params: { mes, anio } });
          setDailySeries(resp2.data || []);
        } catch (e) {
          setDailySeries([]);
        }
      } else {
        const response = await apiClient.get(`/recaudos/campana/${campanaSeleccionada.nombre}`, {
          params
        });
        setRecaudoData(response.data);
        setDailySeries([]);
      }
    } catch (error) {
      console.error('Error al cargar recaudo:', error);
      setRecaudoData({ recaudo_total: 0, cantidad_recaudos: 0 });
      setDailySeries([]);
    } finally {
      setLoadingRecaudo(false);
    }
  };

  // Cargar recaudo cuando cambie la campaña, el mes o el filtro de tiempo
  useEffect(() => {
    cargarRecaudo();
    cargarMeta();
  }, [campanaId, monthState, activeTab]);

  // Usar el recaudo real o mock si está cargando
  const recaudoActual = recaudoData?.recaudo_total || recaudoData?.total_pais || 0;

  const mockKpiData = {
    CLIENTES_TOTALES: 1250, CLIENTES_GESTIONABLES: 980, RECAUDO_Q: recaudoActual,
    META: metaTotal || 500000, CLIENTES_CONTACTADOS: 750, TICKET_CONTACTO: 1200,
    ACUERDOS_Q: 320, ACUERDOS_DOLAR: 380000, TICKET_ACUERDOS: 1187,
    EFECTIVIDAD: 0.426, PLANTA: 45
  };

  // Timeline mock data (días del mes)
  // If we have a daily series from the API use it; otherwise fall back to mock
  const timelineData = (dailySeries && dailySeries.length > 0) ?
    dailySeries.map((item, idx) => ({
      day: idx + 1,
      date: dayjs(item.fecha).format('DD/MM'),
      value: item.total
    })) :
    Array.from({ length: 20 }, (_, i) => ({
      day: i + 1,
      date: monthState.date(i + 1).format("DD/MM"),
      value: Math.floor(Math.random() * 50000) + 20000
    }));

  const metaDelMes = mockKpiData.META;
  
  // Verificar si el mes seleccionado es el actual o futuro
  const mesSeleccionado = monthState.startOf('month');
  const mesActual = now.startOf('month');
  const esMesActualOFuturo = mesSeleccionado.isSame(mesActual) || mesSeleccionado.isAfter(mesActual);
  const esMesPasado = mesSeleccionado.isBefore(mesActual);
  
  // Calcular progreso usando días del contexto
  const diasTranscurridos = esMesActualOFuturo ? (totalDiasLaborables - daysToGo) : totalDiasLaborables;
  const progressRatio = totalDiasLaborables > 0 ? diasTranscurridos / totalDiasLaborables : 1;
  
  const recaudoPonderado = progressRatio > 0 
    ? recaudoActual / progressRatio
    : 0;
  const cumplimientoMeta = metaDelMes > 0 ? recaudoActual / metaDelMes : 0;

  // Calcular "por día" según el tipo de mes
  let porDiaValor = 0;
  let porDiaLabel = '';
  let diasRestantesCalculo = 0;
  
  if (esMesPasado) {
    // Mes pasado: mostrar recaudo promedio por día laborable
    porDiaValor = totalDiasLaborables > 0 ? recaudoActual / totalDiasLaborables : 0;
    porDiaLabel = `Promedio por día (${totalDiasLaborables} días):`;
    diasRestantesCalculo = 0;
  } else {
    // Mes actual o futuro: mostrar lo que falta por día
    diasRestantesCalculo = daysToGo;
    porDiaValor = diasRestantesCalculo > 0 ? (metaDelMes - recaudoActual) / diasRestantesCalculo : 0;
    porDiaLabel = `Por día (${diasRestantesCalculo} restantes):`;
  }
  
  const recaudoCard = {
    actual: recaudoActual, 
    ponderado: recaudoPonderado, 
    meta: metaDelMes,
    cumplimiento: cumplimientoMeta, 
    porDia: porDiaValor,
    porDiaLabel: porDiaLabel,
    mostrarPorDia: esMesPasado || diasRestantesCalculo > 0
  };

  const scrollTimeline = (direction) => {
    const track = document.querySelector('.timeline-track');
    if (track) {
      const scrollAmount = 300;
      track.scrollBy({ left: direction === 'left' ? -scrollAmount : scrollAmount, behavior: 'smooth' });
    }
  };

  const scrollDays = (dir) => {
    const track = document.querySelector(".kpi-days-track");

    if (track) {
      track.scrollBy({
        left: dir === "left" ? -300 : 300,
        behavior: "smooth",
      });
    }
  };

  const { Panel } = Collapse;


  return (
    <div className="kpi-dashboard">

      {/* ===================== HEADER ===================== */}
      <div className="dashboard-header">
        <h1 className="dashboard-title">Torre de Control</h1>
        <div className="dashboard-subtitle">Monitoreo KPI, Metas, OKR y Logros</div>
      </div>

      {/* ===================== FILTROS SUPERIORES ===================== */}
      <div className="filter-bar">
        <Space size="middle" wrap align="center">
          <label>Campaña:</label>
          <Select 
            value={campanaId} 
            onChange={setCampanaId} 
            style={{ width: 200 }}
            placeholder="Seleccione una campaña"
          >
            {campanas.map((c) => (
              <Option key={c.id} value={c.id}>
                {c.nombre}
              </Option>
            ))}
          </Select>

          <label>Mes:</label>
          <DatePicker
            picker="month"
            value={monthState}
            onChange={(v) => v && setMonthState(v)}
            format="MMMM YYYY"
            allowClear={false}
          />

          {/* BOTÓN AVANZADO */}
          <div className="filter-actions">
            <Button 
              className="btn-avanzado"
              onClick={() => window.open('https://app.powerbi.com/view?r=eyJrIjoiOTk3OTIxNjEtNDA2OS00ZDZlLTg1MzMtMDE0NWNkYzBlYTViIiwidCI6IjU4M2VkYjBiLWE4YWQtNGQ5ZS1iNDg2LTE3OGE0ODdjYmMzNyIsImMiOjR9', '_blank')}
            >
              Tesorería <span className="plus">+</span>
            </Button>
          </div>
        </Space>
      </div>

      {/* ===================== PROGRESS BAR ===================== */}
      <div className="progress-strip">
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${progressRatio * 100}%` }} />
        </div>
      </div>

      {/* ======================================================== */}
      {/* =============== SECCIÓN PRINCIPAL DEL GRID ============= */}
      {/* ======================================================== */}

      <div className="main-grid">

        {/* Tarjeta Recaudo Principal */}
        <div className="recaudo-card kpi-card">
          <div className="recaudo-main">
            <div className="recaudo-inner">
              <div className="recaudo-label">Recaudo a la Fecha</div>
              <div className="recaudo-value">
                {loadingRecaudo ? <Spin size="small" /> : fmt.money0(recaudoCard.actual)}
              </div>
            </div>

            <div className="meta-box">
              <div className="meta-label">Meta del Mes</div>
              <div className="meta-value">{fmt.money0(recaudoCard.meta)}</div>
            </div>
          </div>

          <div className="recaudo-metrics">
            <div className="metric-item">
              <div className="metric-label">Cumplimiento:</div>
              <div className="metric-value" style={{ color: recaudoCard.cumplimiento >= 1 ? '#10B981' : '#F59E0B' }}>
                {fmt.percent2(recaudoCard.cumplimiento)}
              </div>
            </div>

            {recaudoCard.mostrarPorDia && (
              <div className="metric-item">
                <div className="metric-label">{recaudoCard.porDiaLabel}</div>
                <div className="metric-value">{fmt.money0(recaudoCard.porDia)}</div>
              </div>
            )}
          </div>
        </div>

      </div>
      {/* ← ← ← ESTE CIERRE ES EL QUE TE FALTABA */}

      {/* ======================================================== */}
      {/* =============== SECCIÓN KPI AVANZADO =================== */}
      {/* ======================================================== */}

      {/* ======================================================== */}
      {/* ========================= NOTA ========================= */}
      {/* ======================================================== */}


      <SeccionIndicadores />

      <HistoricoCumplimiento />




    </div>

  );
};

export default KpiTablero;
