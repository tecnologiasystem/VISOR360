import React, { useState } from 'react';
import { Row, Col, Form, Input, Button, Alert, Typography, Card } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const { Title } = Typography;

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const onFinish = async (values) => {
    setLoading(true);
    setErrorMessage('');
    
    const result = await login(values.username, values.password);
    setLoading(false);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setErrorMessage(result.error || 'Credenciales inválidas.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-background-overlay"></div>
      
      {/* Elementos de fondo animados */}
      <div className="floating-shapes">
        <div className="shape shape-1"></div>
        <div className="shape shape-2"></div>
        <div className="shape shape-3"></div>
        <div className="shape shape-4"></div>
        <div className="shape shape-5"></div>
      </div>

      {/*formulario */}
      <div className="login-right-section">
        <Card className="login-card">
          
          <div className="login-header">
            <div className="login-title-section">
              <Title level={2} className="login-title">
                <strong className="title-gradient">¡Hola!</strong>
              </Title>
              <p className="login-subtitle">
                <span className="subtitle-animated">Nos encanta tenerte por acá</span>
              </p>
            </div>
          </div>

          {errorMessage && (
            <Alert 
              message={errorMessage} 
              type="error" 
              showIcon 
              className="error-alert animated-alert"
            />
          )}

          <Form
            name="login"
            initialValues={{ remember: true }}
            onFinish={onFinish}
            layout="vertical"
            requiredMark={false}
            className="login-form"
          >
            <Form.Item
              name="username"
              label={
                <span className="label-animated">
                  Usuario
                </span>
              }
              rules={[{ required: true, message: 'Por favor ingrese su usuario' }]}
              className="form-item-custom"
            >
              <Input 
                prefix={<UserOutlined className="input-icon" />} 
                placeholder="Ingrese su usuario" 
                size="large"
                className="input-custom input-animated"
              />
            </Form.Item>

            <Form.Item
              name="password"
              label={
                <span className="label-animated">
                  
                  Contraseña
                </span>
              }
              rules={[{ required: true, message: 'Por favor ingrese su contraseña' }]}
              className="form-item-custom"
            >
              <Input.Password 
                prefix={<LockOutlined className="input-icon" />} 
                placeholder="Ingrese su contraseña" 
                size="large"
                className="input-custom input-animated"
              />
            </Form.Item>

            <Form.Item className="submit-section">
              <Button 
                type="primary" 
                htmlType="submit" 
                size="large" 
                loading={loading}
                className="login-button button-animated"
              >
                <span className="button-content">
                  {loading ? (
                    <>
                      <span className="loading-spinner"></span>
                      Ingresando...
                    </>
                  ) : (
                    <>
                      Ingresar 
                    </>
                  )}
                </span>
              </Button>
            </Form.Item>
          </Form>
          <div className="powered-by">
            <div className="powered-content">
              <a 
                href="https://www.systemgroupglobal.com/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="powered-logo-link"
              >
                <img src="/img/powe.png" alt="Powered by SystemGroup" className="powered-logo" />
              </a>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Login;
