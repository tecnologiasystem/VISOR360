import React, { useState, useEffect } from 'react';
import { Spin } from 'antd';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { apiClient } from '../services/apiService';
import './GraficoMetaRecaudo.css';

export default function GraficoMetaRecaudo({ idPais, mes, anio, metaTotal }) {
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState([]);
  const [diasLaborables, setDiasLaborables] = useState([]);

  useEffect(() => {
    cargarDatos();
  }, [idPais, mes, anio, metaTotal]);

  const cargarDatos = async () => {
    setLoading(true);
    try {
      // Obtener días laborables del mes
      const respDias = await apiClient.get('/utils/dias-laborables', {
        params: { mes, anio }
      });
      
      // API devuelve { fechas: [...] }
      const dias = respDias.data.fechas || [];
      setDiasLaborables(dias);

      // Obtener recaudos diarios: soportar idNum o nombre de pais
      let recaudos = [];
      try {
        if (isNaN(Number(idPais))) {
          // idPais es un nombre (ej. 'NPL COL') -> usar endpoint por nombre
          const name = encodeURIComponent(idPais);
          const respRecaudos = await apiClient.get(`/recaudos/pais_by_name/${name}/diario`, { params: { mes, anio } });
          recaudos = respRecaudos.data || [];
        } else {
          const respRecaudos = await apiClient.get(`/recaudos/pais/${idPais}/diario`, { params: { mes, anio } });
          recaudos = respRecaudos.data || [];
        }
      } catch (err) {
        console.error('Error fetching recaudos diarios:', err);
        recaudos = [];
      }
      
      // Crear mapa de recaudos por fecha
      const recaudosPorFecha = {};
      recaudos.forEach(r => {
        const fecha = r.fecha.split('T')[0]; // YYYY-MM-DD
        recaudosPorFecha[fecha] = r.total;
      });

      // Calcular meta diaria (meta total / días laborables)
      const metaDiaria = dias.length > 0 ? metaTotal / dias.length : 0;

      // Construir datos para el gráfico
      let acumulado = 0;
      const data = dias.map((fechaStr, idx) => {
        const fecha = new Date(fechaStr);
        const fechaKey = fechaStr.split('T')[0];
        const recaudoDelDia = recaudosPorFecha[fechaKey] || 0;
        acumulado += recaudoDelDia;

        const diaNum = idx + 1;
        const metaAcumulada = metaDiaria * diaNum;

        return {
          dia: `Día ${diaNum}`,
          diaNum,
          fecha: `${fecha.getDate().toString().padStart(2, '0')}/${(fecha.getMonth() + 1).toString().padStart(2, '0')}`,
          recaudoAcumulado: acumulado,
          metaAcumulada,
          recaudoDelDia,
          metaDiaria
        };
      });

      // Calcular pronóstico con regresión lineal
      // Solo usar datos hasta hoy (donde hay recaudo real)
      const hoy = new Date();
      const datosReales = data.filter(d => {
        const [dia, mes] = d.fecha.split('/').map(Number);
        const fechaDato = new Date(anio, mes - 1, dia);
        return fechaDato <= hoy && d.recaudoAcumulado > 0;
      });

      if (datosReales.length >= 2) {
        // Regresión lineal: y = mx + b
        const n = datosReales.length;
        const sumX = datosReales.reduce((acc, d) => acc + d.diaNum, 0);
        const sumY = datosReales.reduce((acc, d) => acc + d.recaudoAcumulado, 0);
        const sumXY = datosReales.reduce((acc, d) => acc + d.diaNum * d.recaudoAcumulado, 0);
        const sumX2 = datosReales.reduce((acc, d) => acc + d.diaNum * d.diaNum, 0);

        const m = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        const b = (sumY - m * sumX) / n;

        // Aplicar pronóstico a todos los días desde el último día real
        const ultimoDiaReal = datosReales[datosReales.length - 1].diaNum;
        data.forEach(d => {
          if (d.diaNum >= ultimoDiaReal) {
            d.pronostico = m * d.diaNum + b;
          }
        });
      }

      setChartData(data);
    } catch (error) {
      console.error('Error al cargar datos del gráfico:', error);
      setChartData([]);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      maximumFractionDigits: 0
    }).format(value);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="grafico-tooltip">
          <div className="tooltip-title">{data.dia} · {data.fecha}</div>
          <div className="tooltip-row">
            <span className="tooltip-label recaudo-label">Recaudo Acum.:</span>
            <span className="tooltip-value">{formatCurrency(data.recaudoAcumulado)}</span>
          </div>
          <div className="tooltip-row">
            <span className="tooltip-label meta-label">Meta Acum.:</span>
            <span className="tooltip-value">{formatCurrency(data.metaAcumulada)}</span>
          </div>
          {data.pronostico && (
            <div className="tooltip-row">
              <span className="tooltip-label pronostico-label">Pronóstico:</span>
              <span className="tooltip-value">{formatCurrency(data.pronostico)}</span>
            </div>
          )}
          <div className="tooltip-divider"></div>
          <div className="tooltip-row">
            <span className="tooltip-label">Recaudo del día:</span>
            <span className="tooltip-value">{formatCurrency(data.recaudoDelDia)}</span>
          </div>
          <div className="tooltip-row">
            <span className="tooltip-label">Meta diaria:</span>
            <span className="tooltip-value">{formatCurrency(data.metaDiaria)}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="grafico-meta-recaudo-loading">
        <Spin size="large" />
        <p>Cargando gráfico...</p>
      </div>
    );
  }

  if (chartData.length === 0) {
    return (
      <div className="grafico-meta-recaudo-empty">
        <p>No hay datos disponibles para mostrar el gráfico.</p>
      </div>
    );
  }

  return (
    <div className="grafico-meta-recaudo-container">
      <div className="grafico-header">
        <h3 className="grafico-title">Meta vs Recaudo Diario</h3>
        <p className="grafico-subtitle">Seguimiento día a día del cumplimiento de meta</p>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart
          data={chartData}
          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis 
            dataKey="dia" 
            tick={{ fontSize: 11, fill: '#666' }}
            angle={-45}
            textAnchor="end"
            height={80}
          />
          <YAxis 
            tick={{ fontSize: 11, fill: '#666' }}
            tickFormatter={formatCurrency}
            width={100}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ paddingTop: '20px' }}
            iconType="line"
          />
          
          {/* Línea de meta acumulada */}
          <Line 
            type="monotone" 
            dataKey="metaAcumulada" 
            stroke="#FF6B6B" 
            strokeWidth={3}
            dot={{ r: 4, fill: '#FF6B6B' }}
            activeDot={{ r: 6 }}
            name="Meta Acumulada"
            strokeDasharray="5 5"
          />
          
          {/* Línea de recaudo acumulado */}
          <Line 
            type="monotone" 
            dataKey="recaudoAcumulado" 
            stroke="#10B981" 
            strokeWidth={3}
            dot={{ r: 4, fill: '#10B981' }}
            activeDot={{ r: 6 }}
            name="Recaudo Acumulado"
          />

          {/* Línea de pronóstico */}
          <Line 
            type="monotone" 
            dataKey="pronostico" 
            stroke="#F59E0B" 
            strokeWidth={2}
            strokeDasharray="8 4"
            dot={false}
            activeDot={{ r: 5 }}
            name="Pronóstico"
            connectNulls
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
