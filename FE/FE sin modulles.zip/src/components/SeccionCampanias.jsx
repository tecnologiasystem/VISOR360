import React, { useState, useEffect } from "react";
import "./SeccionCampanias.css";
import { apiClient } from "../services/apiService";
import apiMain from "../api";
import { Spin } from "antd";

const fmt = (v) => {
  if (!v) return "$0";
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0
  }).format(v);
};

const fmtPercent = (v) => {
  if (!v && v !== 0) return "0%";
  return `${Math.round(v * 100)}%`;
};

export default function SeccionCampanias({ idPais, mes, anio, nombreCampana, meses }) {
  const [subcampanas, setSubcampanas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [metasPorMes, setMetasPorMes] = useState({});

  useEffect(() => {
    const cargarSubcampanas = async () => {
      // meses: array of {mes, anio} expected; fallback to single month
      const months = Array.isArray(meses) && meses.length ? meses : [{ mes, anio }];
      if ((!idPais && !nombreCampana) || !months.length) return;

      setLoading(true);
      try {
        // Cargar metas para cada mes
        const metasResponses = await Promise.all(months.map(async (m) => {
          try {
            if (nombreCampana) {
              const paisName = encodeURIComponent(nombreCampana);
              const resp = await apiMain.get(`/metas-campana/pais/${paisName}`, {
                params: { mes: m.mes, anio: m.anio }
              });
              return { mes: m.mes, anio: m.anio, metas: resp.data.metas_subcampanas || [] };
            }
            return { mes: m.mes, anio: m.anio, metas: [] };
          } catch (e) {
            return { mes: m.mes, anio: m.anio, metas: [] };
          }
        }));

        // Crear mapa de metas: mes_anio -> { nombre_campana: meta_valor }
        const metasMap = {};
        metasResponses.forEach(({ mes: m, anio: a, metas }) => {
          const key = `${m}_${a}`;
          metasMap[key] = {};
          metas.forEach((meta) => {
            metasMap[key][meta.nombre_campana] = meta.meta_valor;
          });
        });
        setMetasPorMes(metasMap);

        // For each month, get the full country data with subcampanas
        const responsesByMonth = await Promise.all(months.map(async (m) => {
          try {
            if (nombreCampana) {
              const paisName = encodeURIComponent(nombreCampana);
              const resp = await apiClient.get(`/recaudos/pais_by_name/${paisName}`, { 
                params: { mes: m.mes, anio: m.anio } 
              });
              return { mes: m.mes, anio: m.anio, data: resp.data };
            } else {
              const resp = await apiClient.get(`/recaudos/pais/${idPais}`, {
                params: { mes: m.mes, anio: m.anio }
              });
              return { mes: m.mes, anio: m.anio, data: resp.data };
            }
          } catch (e) {
            return { mes: m.mes, anio: m.anio, data: { subcampanas: [] } };
          }
        }));

        // Build a map: subcampana name -> [total_month1, total_month2, total_month3]
        const subcampanasMap = new Map();
        
        responsesByMonth.forEach((monthResp, idx) => {
          const subcamps = monthResp.data?.subcampanas || [];
          subcamps.forEach((sub) => {
            const name = sub.nombre_campana || sub.nombre || sub.name || '';
            if (!subcampanasMap.has(name)) {
              subcampanasMap.set(name, new Array(months.length).fill(0));
            }
            subcampanasMap.get(name)[idx] = sub.total || sub.recaudo_total || 0;
          });
        });

        // Convert map to array and filter out subcampañas with all zeros
        const result = Array.from(subcampanasMap.entries())
          .map(([name, totals]) => ({
            nombre_campana: name,
            totals_by_month: totals
          }))
          .filter(sub => {
            // Filtrar subcampañas que tienen al menos un mes con recaudo > 0
            return sub.totals_by_month.some(total => total > 0);
          });

        setSubcampanas(result);
      } catch (error) {
        console.error('Error al cargar subcampañas:', error);
        setSubcampanas([]);
      } finally {
        setLoading(false);
      }
    };

    cargarSubcampanas();
  }, [idPais, nombreCampana, meses, mes, anio]);

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '20px' }}><Spin /></div>;
  }

  return (
    <div className="campanias-wrapper">

      {/* === TITULO CAMPAÑA === */}
      <div className="campanias-title">Campaña</div>

      {/* === ENCABEZADO CON MESES === */}
      <div className="campanias-header-row">
        <div className="campanias-header-spacer"></div>
        {(Array.isArray(meses) && meses.length ? meses : [{ mes, anio }]).map((m, idx) => {
          const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          const monthLabel = `${monthNames[m.mes - 1]} ${m.anio}`;
          return (
            <div className="campanias-header-month" key={idx}>{monthLabel}</div>
          );
        })}
      </div>

      {/* === TABLA === */}
      <div className="campanias-table">
        {subcampanas.map((sub, i) => {
          const monthsArr = Array.isArray(meses) && meses.length ? meses : [{ mes, anio }];
          const totals = sub.totals_by_month || [];

          return (
            <div className="campania-row" key={i}>

              {/* COLUMNA: NOMBRE */}
              <div className="campania-nombre">{sub.nombre_campana}</div>

              {/* One block per month */}
              {monthsArr.map((m, j) => {
                const recaudo = totals[j] || 0;
                const metaKey = `${m.mes}_${m.anio}`;
                
                // Buscar meta con match case-insensitive
                let meta = 0;
                if (metasPorMes[metaKey]) {
                  // Buscar coincidencia exacta primero
                  meta = metasPorMes[metaKey][sub.nombre_campana];
                  
                  // Si no encuentra, buscar case-insensitive
                  if (!meta) {
                    const lowerName = sub.nombre_campana.toLowerCase();
                    const metaEntry = Object.entries(metasPorMes[metaKey]).find(
                      ([key]) => key.toLowerCase() === lowerName
                    );
                    meta = metaEntry ? metaEntry[1] : 0;
                  }
                }
                
                const cumplimiento = meta > 0 ? recaudo / meta : null;
                return (
                  <div className="campania-block" key={j}>
                    <span className="blue">{fmt(recaudo)}</span>
                    <span className="blue">{meta > 0 ? fmt(meta) : '-'}</span>
                    <span className="orange">{cumplimiento !== null ? fmtPercent(cumplimiento) : '-'}</span>
                  </div>
                );
              })}

            </div>
          );
        })}
      </div>
    </div>
  );
}


