// src/components/HistoricoCumplimiento.jsx

import React, { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { apiClient } from "../services/apiService";
import apiMain from "../api";
import "./HistoricoCumplimiento.css";

const PAISES = ["NPL COL", "ACC", "NPL PER", "NPL CHILE"];

// Función para obtener los meses específicos: septiembre, octubre y noviembre 2025
const getUltimos3Meses = () => {
  return [
    { nombre: 'Septiembre', mes: 9, anio: 2025 },
    { nombre: 'Octubre', mes: 10, anio: 2025 },
    { nombre: 'Noviembre', mes: 11, anio: 2025 }
  ];
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{
        backgroundColor: 'white',
        border: '1px solid #ccc',
        padding: '12px',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
      }}>
        <p style={{ margin: 0, fontWeight: 'bold', color: '#002F9E', marginBottom: '4px' }}>
          {label}
        </p>
        <p style={{ margin: 0, color: '#002F9E', fontSize: '18px', fontWeight: 'bold' }}>
          {payload[0].value}%
        </p>
        <p style={{ margin: 0, fontSize: '12px', color: '#666', marginTop: '4px' }}>
          Cumplimiento
        </p>
      </div>
    );
  }
  return null;
};

const HistoricoCumplimiento = () => {
  const mesesConfig = getUltimos3Meses();
  const [data, setData] = useState(() => {
    const initial = {};
    mesesConfig.forEach(m => initial[m.nombre] = []);
    return initial;
  });

  useEffect(() => {
    const fetchData = async () => {

      const dataByMonth = {};

      for (const mesConfig of mesesConfig) {
        const paisesData = await Promise.all(
          PAISES.map(async (pais) => {
            try {
              // Obtener recaudo
              const paisName = encodeURIComponent(pais);
              const respRecaudo = await apiClient.get(`/recaudos/pais_by_name/${paisName}`, {
                params: { mes: mesConfig.mes, anio: mesConfig.anio }
              });
              const recaudo = respRecaudo.data?.recaudo_total || respRecaudo.data?.total_pais || 0;

              // Obtener meta
              const respMeta = await apiMain.get(`/metas-campana/pais/${paisName}`, {
                params: { mes: mesConfig.mes, anio: mesConfig.anio }
              });
              const meta = respMeta.data?.meta_total || 0;

              // Calcular cumplimiento en porcentaje
              const cumplimiento = meta > 0 ? Math.round((recaudo / meta) * 100) : 0;

              return {
                name: pais.replace('NPL ', ''),
                valor: cumplimiento
              };
            } catch (error) {
              console.error(`Error cargando datos para ${pais} en ${mesConfig.nombre}:`, error);
              return {
                name: pais.replace('NPL ', ''),
                valor: 0
              };
            }
          })
        );

        dataByMonth[mesConfig.nombre] = paisesData;
      }

      setData(dataByMonth);
    };

    fetchData();
  }, []);

  return (
    <div className="historico-wrapper">
      <h3 className="hist-title">Histórico de cumplimiento</h3>

      {/* CONTENEDOR PRINCIPAL */}
      <div className="hist-container">

        {/* Tarjetas de meses */}
        {mesesConfig.map((mesConfig) => (
          <div key={mesConfig.nombre} className="hist-card">
            <h4 className="hist-mes">{mesConfig.nombre}</h4>

            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={data[mesConfig.nombre]} barCategoryGap="25%">
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis 
                  hide={false}
                  tick={{ fontSize: 11 }}
                  tickFormatter={(value) => `${value}%`}
                  domain={[0, 100]}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="valor" fill="#002F9E" radius={[4, 4, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ))}

      </div>
    </div>
  );
};

export default HistoricoCumplimiento;
