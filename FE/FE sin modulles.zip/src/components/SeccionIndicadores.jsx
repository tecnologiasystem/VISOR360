// src/components/SeccionIndicadores.jsx

import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import { apiClient as api } from "../services/apiService";
import apiMain from "../api";
import { useDiasLaborables } from "../contexts/DiasLaborablesContext";
import "./SeccionIndicadores.css";

// 🚀 Importamos los componentes que irán dentro del panel
import ComparativoNPL from "../pages/ComparativoNPL";
import SeccionCampanias from "./SeccionCampanias";
import VisualizacionNPL from "./VisualizacionNPL";
import RecaudoDiario from "./RecaudoDiario";


const indicadores = [
  { id: 2, nombre: "NPL COL", region: "COL", idPais: 10025, nombreCampana: "NPL COL" },
  { id: 1, nombre: "ACC", region: "COL", idPais: 10028, nombreCampana: "ACC" },
  { id: 3, nombre: "NPL PER", region: "PER", idPais: null, nombreCampana: "NPL PER" },
  { id: 4, nombre: "NPL CHILE", region: "CHI", idPais: null, nombreCampana: "NPL CHILE" },
];

// Componente interno para cada mes
const MesColumna = ({ idPais, nombreCampana, mes, anio, label, isActual, diasRestantes, onClickDias }) => {
  const { data: recaudoData } = useQuery({
    queryKey: ["recaudo-mes", idPais, nombreCampana, mes, anio],
    queryFn: async () => {
      // Prefer querying by campaign/country name when available (maps to Excel names)
      if (nombreCampana) {
        const paisName = encodeURIComponent(nombreCampana);
        const res = await api.get(`/recaudos/pais_by_name/${paisName}`, { params: { mes, anio } });
        return res.data;
      }
      if (!idPais) return null;
      const res = await api.get(`/recaudos/pais/${idPais}`, { params: { mes, anio } });
      return res.data;
    },
    enabled: !!idPais || !!nombreCampana,
    staleTime: 5 * 60 * 1000, // Cache por 5 minutos
    cacheTime: 10 * 60 * 1000 // Mantener en cache 10 minutos
  });

  // Query para obtener meta desde la nueva tabla metas_campana_pequena
  const { data: metaData } = useQuery({
    queryKey: ["meta-campana-mes", nombreCampana, mes, anio],
    queryFn: async () => {
      if (!nombreCampana) return null;
      const paisName = encodeURIComponent(nombreCampana);
      const res = await apiMain.get(`/metas-campana/pais/${paisName}`, { params: { mes, anio } });
      return res.data;
    },
    enabled: !!nombreCampana,
    staleTime: 5 * 60 * 1000,
    cacheTime: 10 * 60 * 1000
  });

  const recaudoTotal = recaudoData?.recaudo_total || recaudoData?.total_pais || recaudoData?.total || 0;
  const metaTotal = metaData?.meta_total || 0;
  const cumplimiento = metaTotal > 0 ? (recaudoTotal / metaTotal) * 100 : 0;

  const formatCurrency = (val) => {
    return new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="indicador-columna">
      <button className={`mes-boton ${isActual ? 'active' : ''}`}>
        {label} | Meta | %Cum {isActual && diasRestantes ? `| Días: ${diasRestantes}` : ''}
      </button>
      <div className={`indicador-box ${isActual ? 'ultimo' : ''}`}>
        <span>{formatCurrency(recaudoTotal)}</span> · 
        <span>{formatCurrency(metaTotal)}</span> · 
        <span className="pct">{cumplimiento.toFixed(0)}%</span>
        {isActual && diasRestantes && (
          <span 
            className="dias" 
            onClick={onClickDias}
            style={{ cursor: "pointer", textDecoration: "underline" }}
            title="Click para editar días laborables"
          >
            | {diasRestantes}
          </span>
        )}
      </div>
    </div>
  );
};


const SeccionIndicadores = () => {
  const [openIds, setOpenIds] = useState([]); // Cambiar a array para múltiples abiertos
  const [mesesSeleccionados, setMesesSeleccionados] = useState([0, 1, 2]); // Índices de los meses seleccionados (todos por defecto)
  const [mostrarFiltros, setMostrarFiltros] = useState(true); // Estado para mostrar/ocultar filtros
  const [mostrarCalendario, setMostrarCalendario] = useState(false);

  // Usar contexto para días laborables
  const { 
    diasLaborablesCustom, 
    diasRestantes: diasRestantesActuales,
    toggleDiaLaborable,
    resetDias
  } = useDiasLaborables();

  // Definir los meses específicos: Septiembre, Octubre, Noviembre
  const meses = useMemo(() => {
    return [
      { mes: 9, anio: 2025, label: "sep", isActual: false },
      { mes: 10, anio: 2025, label: "oct", isActual: false },
      { mes: 11, anio: 2025, label: "nov", isActual: true },
    ];
  }, []);

  const mesesAMostrar = mesesSeleccionados.map(idx => meses[idx]);

  const toggle = (id) => {
    setOpenIds((prev) => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleMes = (idx) => {
    setMesesSeleccionados(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx].sort()
    );
  };

  return (
    <div className="indicadores-wrapper" style={{ zoom: "0.8" }}>

      {/* Botón para mostrar/ocultar filtros */}
      {!mostrarFiltros && (
        <button
          onClick={() => setMostrarFiltros(true)}
          style={{
            position: "fixed",
            left: "20px",
            top: "120px",
            backgroundColor: "#003087",
            color: "white",
            border: "none",
            borderRadius: "8px",
            padding: "12px 16px",
            cursor: "pointer",
            fontSize: "14px",
            fontWeight: 600,
            boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
            zIndex: 100
          }}
        >
          📅 Mostrar Filtros
        </button>
      )}

      {/* Filtro: Checkboxes para cada mes - Panel lateral fijo */}
      {mostrarFiltros && (
        <div style={{ 
          position: "fixed", 
          left: "20px", 
          top: "120px", 
          backgroundColor: "white", 
          padding: "20px", 
          borderRadius: "12px", 
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          border: "1px solid #e5e7eb",
          zIndex: 100,
          width: "200px"
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
            <div style={{ fontWeight: 600, color: "#003087", fontSize: "14px" }}>
              Seleccionar meses
            </div>
            <button
              onClick={() => setMostrarFiltros(false)}
              style={{
                backgroundColor: "transparent",
                border: "none",
                fontSize: "18px",
                cursor: "pointer",
                color: "#6b7280",
                padding: "0",
                lineHeight: "1"
              }}
              title="Ocultar filtros"
            >
              ✕
            </button>
          </div>
          {meses.map((m, idx) => (
            <label key={idx} style={{ 
              display: "flex", 
              alignItems: "center", 
              gap: "8px", 
              marginBottom: "12px",
              cursor: "pointer",
              fontSize: "14px",
              color: "#1f2937"
            }}>
              <input 
                type="checkbox"
                checked={mesesSeleccionados.includes(idx)} 
                onChange={() => toggleMes(idx)}
                style={{ cursor: "pointer", accentColor: "#003087" }}
              />
              {m.label} {m.anio}
            </label>
          ))}
        </div>
      )}

      {/* Contenido principal con margen para el panel lateral */}
      <div style={{ marginLeft: "0px" }}>

      {indicadores.map((item) => (
        <div key={item.id} className="indicador-container">
          
          <div className="indicador-main-row">
            {/* Badge que ocupa todo el alto */}
            <div
              className="indicador-badge"
              onClick={() => toggle(item.id)}
              style={{ cursor: "pointer" }}
            >
              <span className={`icon ${openIds.includes(item.id) ? "open" : ""}`}>▲</span> {item.nombre}
            </div>

            {/* Renderizar columnas según filtro */}
            {mesesAMostrar.map((m, idx) => (
              <MesColumna 
                  key={`${item.id}-${m.mes}-${m.anio}`}
                  idPais={item.idPais}
                  nombreCampana={item.nombreCampana || item.nombre}
                  mes={m.mes}
                  anio={m.anio}
                  label={m.label}
                  isActual={m.isActual}
                  diasRestantes={m.isActual ? diasRestantesActuales : null}
                  onClickDias={() => setMostrarCalendario(true)}
                />
            ))}
          </div>

          {/* === CONTENIDO DESPLEGABLE === */}
          {openIds.includes(item.id) && (
            <div className="indicador-panel full-width-panel animate-panel">

              {/* 1) Sección de Visualización */}
              {/*<VisualizacionNPL />*/}

              {/* 2) Tabla Campañas - MES ACTUAL */}
              <SeccionCampanias 
                idPais={item.idPais} 
                nombreCampana={item.nombreCampana || item.nombre}
                mes={meses[2].mes}
                anio={meses[2].anio}
                meses={mesesAMostrar}
              />

              {/* 3) Gráfica Comparativo */}
              <div className="chart-wrapper" style={{ marginTop: "20px" }}>
                <ComparativoNPL nombreCampana={item.nombreCampana || item.nombre} />
              </div>

            </div>
          )}

        </div>
      ))}

      </div> {/* Cierre del div con margen */}

      {/* Modal de Calendario para editar días laborables */}
      {mostrarCalendario && (
        <div 
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000
          }}
          onClick={() => setMostrarCalendario(false)}
        >
          <div 
            style={{
              backgroundColor: "white",
              borderRadius: "16px",
              padding: "24px",
              maxWidth: "600px",
              maxHeight: "80vh",
              overflowY: "auto",
              boxShadow: "0 4px 24px rgba(0,0,0,0.2)"
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <h3 style={{ margin: 0, color: "#003087", fontSize: "18px", fontWeight: 600 }}>
                📅 Días Laborables del Mes
              </h3>
              <button
                onClick={() => setMostrarCalendario(false)}
                style={{
                  backgroundColor: "transparent",
                  border: "none",
                  fontSize: "24px",
                  cursor: "pointer",
                  color: "#6b7280",
                  padding: "0",
                  lineHeight: "1"
                }}
              >
                ✕
              </button>
            </div>

            <p style={{ color: "#6b7280", fontSize: "14px", marginBottom: "20px" }}>
              Selecciona los días que se considerarán como laborables. Los cambios afectarán el cálculo de "Por día" en todas las secciones.
            </p>

            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(80px, 1fr))",
              gap: "8px"
            }}>
              {diasLaborablesCustom.map((dia) => {
                const esHoy = dia.fecha === dayjs().format("YYYY-MM-DD");
                const esPasado = dia.fecha < dayjs().format("YYYY-MM-DD");
                
                return (
                  <button
                    key={dia.fecha}
                    onClick={() => toggleDiaLaborable(dia.fecha)}
                    disabled={esPasado}
                    style={{
                      padding: "12px 8px",
                      borderRadius: "8px",
                      border: esHoy ? "2px solid #003087" : dia.activo ? "2px solid #10b981" : "2px solid #e5e7eb",
                      backgroundColor: esPasado 
                        ? "#f3f4f6" 
                        : dia.activo 
                          ? esHoy ? "#003087" : "#10b981"
                          : "white",
                      color: esPasado 
                        ? "#9ca3af" 
                        : dia.activo 
                          ? "white" 
                          : "#6b7280",
                      cursor: esPasado ? "not-allowed" : "pointer",
                      fontSize: "13px",
                      fontWeight: esHoy ? 600 : dia.activo ? 500 : 400,
                      transition: "all 0.2s",
                      opacity: esPasado ? 0.5 : 1,
                      textAlign: "center"
                    }}
                    title={esPasado ? "Día pasado (no editable)" : dia.activo ? "Click para desactivar" : "Click para activar"}
                  >
                    <div>{dia.label}</div>
                    {esHoy && <div style={{ fontSize: "10px", marginTop: "2px" }}>HOY</div>}
                  </button>
                );
              })}
            </div>

            <div style={{ 
              marginTop: "20px", 
              padding: "16px", 
              backgroundColor: "#f3f4f6", 
              borderRadius: "8px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}>
              <div>
                <div style={{ fontSize: "14px", color: "#6b7280", marginBottom: "4px" }}>
                  Días laborables restantes (incluyendo hoy):
                </div>
                <div style={{ fontSize: "24px", fontWeight: 700, color: "#003087" }}>
                  {diasRestantesActuales} días
                </div>
              </div>
              <button
                onClick={() => {
                  // Resetear a valores por defecto (todos los L-V)
                  resetDias();
                }}
                style={{
                  padding: "10px 16px",
                  backgroundColor: "#003087",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                Resetear Todo
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default SeccionIndicadores;

