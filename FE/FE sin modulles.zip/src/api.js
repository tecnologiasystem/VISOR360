import axios from 'axios';

// Usar la misma configuración que apiClient - proxy a través de IIS
const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

export default api;