import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { DiasLaborablesProvider } from './contexts/DiasLaborablesContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardRedirect from './components/DashboardRedirect';
import Login from './pages/Login';
import MainLayout from './layouts/MainLayout';
import KpiTablero from './pages/KpiTablero';
import TableroFinanciero from './pages/TableroFinanciero';
import TableroTalentoHumano from './pages/TableroTalentoHumano';
import GestionMetas from './pages/GestionMetas';

function App() {
  return (
    <AuthProvider>
      <DiasLaborablesProvider>
        <Router>
          <Routes>
            {/* Public route */}
            <Route path="/login" element={<Login />} />
            
            {/* Protected routes with MainLayout */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<DashboardRedirect />} />
              <Route path="dashboard" element={<DashboardRedirect />} />
              
              {/* KPI route - dentro del layout */}
              <Route path="kpi" element={<KpiTablero />} />
              
              {/* Rutas protegidas por permisos específicos */}
              <Route 
                path="financiero" 
                element={
                  <ProtectedRoute requiredPermission="view_finance">
                    <TableroFinanciero />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="talento" 
                element={
                  <ProtectedRoute requiredPermission="view_hr">
                    <TableroTalentoHumano />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="gestion-metas" 
                element={
                  <GestionMetas />
                } 
              />
            </Route>

            {/* Catch all - redirect to login */}
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </Router>
      </DiasLaborablesProvider>
    </AuthProvider>
  );
}

export default App;
